import customtkinter as ctk
import sys
import os

# Adicionar o diretório atual ao path para importações
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from ui.styles import *
from ui.tela_inicio import TelaInicio
from ui.tela_biblioteca import TelaBiblioteca
from ui.tela_dashboard import TelaDashboard
from ui.tela_adicionar import TelaAdicionar
from database.database import init_db

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        init_db()
        
        self.title("Catálogo de Livros")
        self.geometry("1200x850")
        self.configure(fg_color=FUNDO_CLARO)
        
        # Layout Principal
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=SIDEBAR_WIDTH, fg_color=MARROM_ESCUDO, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        
        # Logo
        self.logo = ctk.CTkLabel(self.sidebar, text="📖 Catálogo", font=FONTE_SUBTITULO, text_color=BRANCO)
        self.logo.pack(pady=(40, 40), padx=20, anchor="w")
        
        # Menu Buttons
        self.btn_inicio = self.criar_menu_button("Início", "home", self.mostrar_inicio)
        self.btn_biblioteca = self.criar_menu_button("Minha Biblioteca", "book", self.mostrar_biblioteca)
        self.btn_estatisticas = self.criar_menu_button("Estatísticas", "bar-chart", self.mostrar_estatisticas)
        
        # Botão Adicionar Livro no rodapé
        self.btn_add = ctk.CTkButton(self.sidebar, text="+ Adicionar Livro", 
                                    fg_color=VERDE_OLIVA, hover_color=VERDE_HOVER,
                                    font=FONTE_CARD_TITULO, height=45, corner_radius=8,
                                    command=self.abrir_modal_adicionar)
        self.btn_add.pack(side="bottom", pady=30, padx=20, fill="x")
        
        # Container de Telas
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.grid(row=0, column=1, sticky="nsew")
        self.container.grid_columnconfigure(0, weight=1)
        self.container.grid_rowconfigure(0, weight=1)
        
        self.telas = {}
        self.setup_telas()
        self.mostrar_inicio()

    def criar_menu_button(self, texto, icone, comando):
        btn = ctk.CTkButton(self.sidebar, text=f"  {texto}", font=FONTE_NORMAL,
                           fg_color="transparent", text_color="#C8DEC7",
                           anchor="w", height=45, hover_color="#3D2B22",
                           command=comando)
        btn.pack(pady=5, padx=10, fill="x")
        return btn

    def setup_telas(self):
        self.telas["inicio"] = TelaInicio(self.container, self)
        self.telas["biblioteca"] = TelaBiblioteca(self.container, self)
        self.telas["estatisticas"] = TelaDashboard(self.container, self)
        self.telas["adicionar"] = TelaAdicionar(self.container, self)
        
        for tela in self.telas.values():
            tela.grid(row=0, column=0, sticky="nsew")

    def mostrar_inicio(self):
        self.mostrar_tela("inicio")
        self.reset_menu_colors()
        self.btn_inicio.configure(fg_color=VERDE_OLIVA, text_color=BRANCO)

    def mostrar_biblioteca(self):
        self.mostrar_tela("biblioteca")
        self.reset_menu_colors()
        self.btn_biblioteca.configure(fg_color=VERDE_OLIVA, text_color=BRANCO)

    def mostrar_estatisticas(self):
        self.mostrar_tela("estatisticas")
        self.reset_menu_colors()
        self.btn_estatisticas.configure(fg_color=VERDE_OLIVA, text_color=BRANCO)

    def reset_menu_colors(self):
        for btn in [self.btn_inicio, self.btn_biblioteca, self.btn_estatisticas]:
            btn.configure(fg_color="transparent", text_color="#C8DEC7")

    def mostrar_tela(self, nome):
        tela = self.telas.get(nome)
        if tela:
            tela.tkraise()
            if hasattr(tela, "atualizar"):
                tela.atualizar()

    def abrir_modal_adicionar(self):
        self.mostrar_tela("adicionar")
        self.reset_menu_colors()

if __name__ == "__main__":
    app = App()
    app.mainloop()
