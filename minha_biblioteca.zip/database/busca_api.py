import requests

def buscar_por_titulo_autor(termo):
    """Busca livros na Google Books API"""
    url = f"https://www.googleapis.com/books/v1/volumes?q={termo}&maxResults=5"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            resultados = []
            for item in data.get('items', []):
                info = item.get('volumeInfo', {})
                resultados.append({
                    'titulo': info.get('title', 'Sem título'),
                    'autor': ", ".join(info.get('authors', ['Desconhecido'])),
                    'ano': info.get('publishedDate', '')[:4],
                    'paginas': info.get('pageCount', 0),
                    'editora': info.get('publisher', 'Desconhecida'),
                    'capa_url': info.get('imageLinks', {}).get('thumbnail', ''),
                    'genero': ", ".join(info.get('categories', ['-']))
                })
            return resultados
    except:
        return []
    return []
