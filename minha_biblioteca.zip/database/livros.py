from .database import execute_query

def _obter_ou_criar_id(tabela, nome):
    if not nome or not str(nome).strip():
        return None
    nome = str(nome).strip()
    res = execute_query(f"SELECT id FROM {tabela} WHERE LOWER(nome) = LOWER(%s)", (nome,), fetch=True)
    if res:
        return res[0]['id']
    execute_query(f"INSERT INTO {tabela} (nome) VALUES (%s)", (nome,))
    res = execute_query(f"SELECT id FROM {tabela} WHERE LOWER(nome) = LOWER(%s)", (nome,), fetch=True)
    return res[0]['id'] if res else None

def _int_or_none(val):
    """Retorna int se válido, ou None — nunca força 0 (evita violar constraints do banco)."""
    try:
        v = int(str(val).strip())
        return v if v > 0 else None
    except (ValueError, TypeError, AttributeError):
        return None

# ── Mapeamento UI <-> banco ───────────────────────────────────────────────────
_STATUS_DB  = {"Quero Ler":"quero_ler","Lendo":"lendo","Lido":"lido",
               "quero_ler":"quero_ler","lendo":"lendo","lido":"lido"}
_STATUS_UI  = {"quero_ler":"Quero Ler","lendo":"Lendo","lido":"Lido"}
_FORMATO_DB = {"Físico":"fisico","Fisico":"fisico","fisico":"fisico",
               "E-book":"ebook","Audiobook":"ebook","ebook":"ebook"}
_FORMATO_UI = {"fisico":"Físico","ebook":"E-book"}

def _sdb(v): return _STATUS_DB.get(v,  "quero_ler")
def _sui(v): return _STATUS_UI.get(v,  "Quero Ler")
def _fdb(v): return _FORMATO_DB.get(v, "fisico")
def _fui(v): return _FORMATO_UI.get(v, "Físico")

# ── Listagem ──────────────────────────────────────────────────────────────────

def listar_livros(status=None):
    query = """
        SELECT l.id, l.titulo, l.paginas, l.status, l.lido, l.avaliacao, l.capa_path,
               l.ano_publicacao, l.formato, l.idioma, l.resenha,
               l.data_inicio, l.data_fim, l.created_at,
               a.nome AS autor, a.nacionalidade AS autor_nacionalidade,
               g.nome AS genero, e.nome AS editora
        FROM livros l
        LEFT JOIN autores  a ON l.autor_id   = a.id
        LEFT JOIN generos  g ON l.genero_id  = g.id
        LEFT JOIN editoras e ON l.editora_id = e.id
    """
    conds = []
    if status == "Lendo":       conds.append("l.status = 'lendo'")
    elif status == "Lidos":     conds.append("l.status = 'lido'")
    elif status == "Quero Ler": conds.append("l.status = 'quero_ler'")
    if conds:
        query += " WHERE " + " AND ".join(conds)
    query += " ORDER BY l.titulo ASC"
    rows = execute_query(query, fetch=True) or []
    for r in rows:
        r['status']  = _sui(r.get('status', ''))
        r['formato'] = _fui(r.get('formato', ''))
    return rows

def buscar_livros(termo):
    q = """
        SELECT l.id, l.titulo, l.paginas, l.status, l.lido, l.avaliacao, l.capa_path,
               a.nome AS autor, g.nome AS genero
        FROM livros l
        LEFT JOIN autores a ON l.autor_id  = a.id
        LEFT JOIN generos g ON l.genero_id = g.id
        WHERE l.titulo ILIKE %s OR a.nome ILIKE %s
        ORDER BY l.titulo ASC
    """
    p = f"%{termo}%"
    rows = execute_query(q, (p, p), fetch=True) or []
    for r in rows:
        r['status'] = _sui(r.get('status', ''))
    return rows

# ── CRUD ──────────────────────────────────────────────────────────────────────

def adicionar_livro(dados):
    autor_id   = _obter_ou_criar_id("autores",  dados.get('autor'))
    genero_id  = _obter_ou_criar_id("generos",  dados.get('genero'))
    editora_id = _obter_ou_criar_id("editoras", dados.get('editora'))

    status_db = _sdb(dados.get('status', 'Quero Ler'))
    lido      = status_db == 'lido'

    # livros_check1: data_inicio e data_fim só podem existir se lido=TRUE
    # data_fim = NOW() automaticamente quando marcado como lido
    return execute_query("""
        INSERT INTO livros
            (titulo, autor_id, genero_id, editora_id, paginas,
             ano_publicacao, formato, idioma, status, lido,
             avaliacao, capa_path, resenha, data_fim)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                CASE WHEN %s THEN NOW()::date ELSE NULL END)
    """, (
        dados['titulo'].strip(),
        autor_id, genero_id, editora_id,
        _int_or_none(dados.get('paginas')),       # NULL se vazio — não viola paginas > 0
        _int_or_none(dados.get('ano')),            # NULL se vazio — não viola ano >= 1000
        _fdb(dados.get('formato', 'Físico')),
        dados.get('idioma', 'Português'),
        status_db, lido,
        dados.get('avaliacao') or None,            # NULL se 0 — avaliacao_check permite NULL
        dados.get('capa_path'),
        dados.get('resenha') or None,
        lido,                                      # data_fim
    ))

def editar_livro(id, dados):
    autor_id   = _obter_ou_criar_id("autores",  dados.get('autor'))
    genero_id  = _obter_ou_criar_id("generos",  dados.get('genero'))
    editora_id = _obter_ou_criar_id("editoras", dados.get('editora'))

    status_db = _sdb(dados.get('status', 'Quero Ler'))
    lido      = status_db == 'lido'

    return execute_query("""
        UPDATE livros SET
            titulo=%s, autor_id=%s, genero_id=%s, editora_id=%s,
            paginas=%s, ano_publicacao=%s, formato=%s, idioma=%s,
            status=%s, lido=%s, avaliacao=%s, resenha=%s,
            data_inicio = CASE WHEN %s THEN COALESCE(data_inicio, NOW()::date) ELSE NULL END,
            data_fim    = CASE WHEN %s THEN COALESCE(data_fim,    NOW()::date) ELSE NULL END
        WHERE id=%s
    """, (
        dados['titulo'].strip(),
        autor_id, genero_id, editora_id,
        _int_or_none(dados.get('paginas')),
        _int_or_none(dados.get('ano')),
        _fdb(dados.get('formato', 'Físico')),
        dados.get('idioma', 'Português'),
        status_db, lido,
        dados.get('avaliacao') or None,
        dados.get('resenha') or None,
        lido,   # data_inicio
        lido,   # data_fim
        id,
    ))

def deletar_libro(id):
    return execute_query("DELETE FROM livros WHERE id = %s", (id,))

def atualizar_capa(id, path):
    return execute_query("UPDATE livros SET capa_path = %s WHERE id = %s", (path, id))

def obter_livro(id):
    res = execute_query("""
        SELECT l.*, a.nome AS autor, a.nacionalidade AS autor_nacionalidade,
               g.nome AS genero, e.nome AS editora
        FROM livros l
        LEFT JOIN autores  a ON l.autor_id   = a.id
        LEFT JOIN generos  g ON l.genero_id  = g.id
        LEFT JOIN editoras e ON l.editora_id = e.id
        WHERE l.id = %s
    """, (id,), fetch=True)
    if res:
        res[0]['status']  = _sui(res[0].get('status', ''))
        res[0]['formato'] = _fui(res[0].get('formato', ''))
    return res[0] if res else None

# ── Agregados ─────────────────────────────────────────────────────────────────

def total_livros():
    res = execute_query("SELECT COUNT(*) as total FROM livros", fetch=True)
    return res[0]['total'] if res else 0

def total_paginas_lidas():
    res = execute_query(
        "SELECT COALESCE(SUM(paginas),0) as total FROM livros WHERE status='lido'", fetch=True)
    return res[0]['total'] if res else 0

def livro_lendo_now():
    res = execute_query("""
        SELECT l.titulo, l.capa_path, a.nome as autor
        FROM livros l LEFT JOIN autores a ON l.autor_id=a.id
        WHERE l.status='lendo' LIMIT 1
    """, fetch=True)
    return res[0] if res else None

def obter_meta(ano):
    res = execute_query("SELECT meta FROM metas WHERE ano=%s", (ano,), fetch=True)
    return res[0]['meta'] if res else 12

def salvar_meta(ano, objetivo):
    # metas tem PK em 'id', não em 'ano' — verifica antes de inserir
    existe = execute_query("SELECT id FROM metas WHERE ano=%s", (ano,), fetch=True)
    if existe:
        return execute_query("UPDATE metas SET meta=%s WHERE ano=%s", (objetivo, ano))
    return execute_query("INSERT INTO metas (ano, meta) VALUES (%s,%s)", (ano, objetivo))

def listar_autores():
    return execute_query("SELECT * FROM autores ORDER BY nome", fetch=True) or []

def listar_generos():
    return execute_query("SELECT * FROM generos ORDER BY nome", fetch=True) or []

def listar_editoras():
    return execute_query("SELECT * FROM editoras ORDER BY nome", fetch=True) or []

def media_avaliacao():
    res = execute_query(
        "SELECT ROUND(AVG(avaliacao)::numeric,1) as media FROM livros WHERE status='lido' AND avaliacao>0",
        fetch=True)
    return float(res[0]['media'] or 0) if res else 0.0

def lidos_no_ano(ano):
    res = execute_query(
        "SELECT COUNT(*) as total FROM livros WHERE status='lido' AND EXTRACT(YEAR FROM data_fim)=%s",
        (ano,), fetch=True)
    return res[0]['total'] if res else 0
