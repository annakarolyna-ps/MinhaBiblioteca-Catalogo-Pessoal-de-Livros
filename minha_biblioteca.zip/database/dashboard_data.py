from .database import execute_query

def stats_gerais():
    def q(sql): return (execute_query(sql, fetch=True) or [{'v':0}])[0]['v']
    total  = q("SELECT COUNT(*) as v FROM livros")
    lidos  = q("SELECT COUNT(*) as v FROM livros WHERE status='lido'")
    lendo  = q("SELECT COUNT(*) as v FROM livros WHERE status='lendo'")
    paginas= q("SELECT COALESCE(SUM(paginas),0) as v FROM livros WHERE status='lido'")
    res    = execute_query("SELECT ROUND(AVG(avaliacao)::numeric,1) as v FROM livros WHERE status='lido' AND avaliacao>0", fetch=True)
    media  = float((res or [{'v':0}])[0]['v'] or 0)
    return {"total": total, "lidos": lidos, "lendo": lendo,
            "nao_lidos": total - lidos - lendo,
            "paginas_lidas": paginas, "media_avaliacao": media}

def livros_por_genero():
    return execute_query("""
        SELECT g.nome as genero, COUNT(l.id) as total
        FROM generos g JOIN livros l ON l.genero_id=g.id
        GROUP BY g.nome ORDER BY total DESC
    """, fetch=True) or []

def livros_por_formato():
    return execute_query("""
        SELECT COALESCE(formato,'Não informado') as formato, COUNT(*) as total
        FROM livros GROUP BY formato ORDER BY total DESC
    """, fetch=True) or []

def lidos_por_ano():
    return execute_query("""
        SELECT EXTRACT(YEAR FROM data_fim)::INT as ano, COUNT(*) as total
        FROM livros WHERE status='lido' AND data_fim IS NOT NULL
        GROUP BY ano ORDER BY ano
    """, fetch=True) or []

def autores_mais_lidos():
    return execute_query("""
        SELECT a.nome as autor, COUNT(l.id) as total
        FROM autores a JOIN livros l ON l.autor_id=a.id
        WHERE l.status='lido' GROUP BY a.nome ORDER BY total DESC LIMIT 6
    """, fetch=True) or []

def distribuicao_avaliacoes():
    return execute_query("""
        SELECT FLOOR(avaliacao)::INT as nota, COUNT(*) as total
        FROM livros WHERE status='lido' AND avaliacao>0
        GROUP BY nota ORDER BY nota
    """, fetch=True) or []

def ritmo_leitura_mensal():
    return execute_query("""
        SELECT TO_CHAR(data_fim,'Mon/YY') as mes,
               EXTRACT(YEAR FROM data_fim)*100 + EXTRACT(MONTH FROM data_fim) as ordem,
               COUNT(*) as total
        FROM livros
        WHERE status='lido' AND data_fim >= NOW() - INTERVAL '12 months'
        GROUP BY mes, ordem ORDER BY ordem
    """, fetch=True) or []
