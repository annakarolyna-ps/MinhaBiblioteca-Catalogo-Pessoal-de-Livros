import psycopg2
from psycopg2.extras import RealDictCursor

DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "catalogo_livros",
    "user": "postgres",
    "password": "628507"
}

def get_connection():
    return psycopg2.connect(**DB_CONFIG)

def execute_query(query, params=None, fetch=False):
    conn = None
    try:
        conn = get_connection()
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            if fetch:
                return [dict(row) for row in cur.fetchall()]
            conn.commit()
            return True
    except Exception as e:
        if conn:
            conn.rollback()
        print(f"[DB ERRO] {e}")
        return [] if fetch else False
    finally:
        if conn:
            conn.close()

def init_db():
    pass
