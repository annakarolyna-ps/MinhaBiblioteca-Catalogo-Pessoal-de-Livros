import customtkinter as ctk
from tkinter import filedialog, messagebox
import os
from .styles import *
from .widget_estrelas import WidgetEstrelas
from database.livros import adicionar_livro, listar_autores, listar_generos, listar_editoras
from database.busca_api import buscar_por_titulo_autor

FORMATOS   = ["Físico", "E-book", "Audiobook"]
STATUS_OPT = ["Quero Ler", "Lendo", "Lido"]

class TelaAdicionar(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color=FUNDO_CLARO, corner_radius=0)
        self.app = app
        self.capa_path = None
        self.avaliacao_widget = None
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(self, text="Adicionar Novo Livro", font=FONTE_TITULO,
                     text_color=TEXTO_PRINCIPAL).grid(row=0, column=0, sticky="w", padx=30, pady=(30,10))

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=30, pady=10)
        self.scroll.grid_columnconfigure(1, weight=1)
        self.setup_ui()

    def _label(self, row, texto):
        ctk.CTkLabel(self.scroll, text=texto, font=FONTE_PEQUENA,
                     text_color=TEXTO_PRINCIPAL).grid(row=row, column=0, sticky="w", pady=6)

    def _entry(self, row, placeholder=""):
        e = ctk.CTkEntry(self.scroll, height=36, placeholder_text=placeholder)
        e.grid(row=row, column=1, sticky="ew", pady=6, padx=(15,0))
        return e

    def _combo(self, row, values, default=None):
        c = ctk.CTkComboBox(self.scroll, values=values, height=36, state="normal")
        if default:
            c.set(default)
        c.grid(row=row, column=1, sticky="ew", pady=6, padx=(15,0))
        return c

    def setup_ui(self):
        # ── Busca automática ──────────────────────────────────────────────
        busca_f = ctk.CTkFrame(self.scroll, fg_color=BRANCO, corner_radius=CORNER_RADIUS,
                               border_width=1, border_color="#E0E0E0")
        busca_f.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0,20))
        busca_f.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(busca_f, text="🔍  Preencher automaticamente pela internet",
                     font=FONTE_CARD_TITULO, text_color=VERDE_OLIVA).grid(
                     row=0, column=0, columnspan=3, padx=15, pady=10, sticky="w")
        self.ent_busca = ctk.CTkEntry(busca_f, placeholder_text="Nome do livro ou autor...", height=36)
        self.ent_busca.grid(row=1, column=0, columnspan=2, padx=15, pady=(0,15), sticky="ew")
        self.ent_busca.bind("<Return>", lambda e: self.buscar())
        ctk.CTkButton(busca_f, text="Buscar", width=100, fg_color=VERDE_OLIVA,
                      hover_color=VERDE_HOVER, command=self.buscar).grid(
                      row=1, column=2, padx=15, pady=(0,15))

        # ── Campos principais ─────────────────────────────────────────────
        self.inputs = {}

        self._label(1, "Título *")
        self.inputs['titulo'] = self._entry(1, "Título do livro")

        self._label(2, "Autor *")
        autores = [a['nome'] for a in listar_autores()]
        self.inputs['autor'] = self._combo(2, autores, "")

        self._label(3, "Gênero")
        generos = [g['nome'] for g in listar_generos()]
        self.inputs['genero'] = self._combo(3, generos, "")

        self._label(4, "Editora")
        editoras = [e['nome'] for e in listar_editoras()]
        self.inputs['editora'] = self._combo(4, editoras, "")

        self._label(5, "Páginas")
        self.inputs['paginas'] = self._entry(5, "Ex: 320")

        self._label(6, "Ano")
        self.inputs['ano'] = self._entry(6, "Ex: 2023")

        self._label(7, "Formato")
        self.inputs['formato'] = self._combo(7, FORMATOS, "Físico")

        # ── Status de leitura ─────────────────────────────────────────────
        self._label(8, "Status *")
        self.status_var = ctk.StringVar(value="Quero Ler")
        status_f = ctk.CTkFrame(self.scroll, fg_color="transparent")
        status_f.grid(row=8, column=1, sticky="ew", pady=6, padx=(15,0))
        self.status_btns = {}
        cores = {"Quero Ler": "#8B5A2B", "Lendo": VERDE_OLIVA, "Lido": "#2D6A2D"}
        for s in STATUS_OPT:
            b = ctk.CTkButton(status_f, text=s, width=95, height=34,
                              fg_color=cores[s], hover_color=VERDE_HOVER,
                              font=FONTE_PEQUENA,
                              command=lambda v=s: self._selecionar_status(v))
            b.pack(side="left", padx=(0,6))
            self.status_btns[s] = b
        self._selecionar_status("Quero Ler")

        # ── Avaliação (estrelas) ──────────────────────────────────────────
        self._label(9, "Avaliação")
        aval_f = ctk.CTkFrame(self.scroll, fg_color="transparent")
        aval_f.grid(row=9, column=1, sticky="w", pady=6, padx=(15,0))
        self.avaliacao_widget = WidgetEstrelas(aval_f, valor_inicial=0, tamanho=20)
        self.avaliacao_widget.pack()

        # ── Capa ─────────────────────────────────────────────────────────
        self._label(10, "Capa")
        capa_f = ctk.CTkFrame(self.scroll, fg_color="transparent")
        capa_f.grid(row=10, column=1, sticky="w", pady=6, padx=(15,0))
        self.lbl_capa = ctk.CTkLabel(capa_f, text="Nenhuma imagem selecionada",
                                     font=FONTE_PEQUENA, text_color=CINZA_TEXTO)
        self.lbl_capa.pack(side="left", padx=(0,10))
        ctk.CTkButton(capa_f, text="📂 Selecionar", width=120, height=32,
                      fg_color=BRANCO, text_color=TEXTO_PRINCIPAL, border_width=1,
                      border_color="#CCCCCC", hover_color="#F0F0F0",
                      command=self.selecionar_capa).pack(side="left")

        # ── Botão salvar ──────────────────────────────────────────────────
        ctk.CTkButton(self.scroll, text="✅  Salvar Livro", font=FONTE_CARD_TITULO,
                      height=48, fg_color=VERDE_OLIVA, hover_color=VERDE_HOVER,
                      command=self.salvar).grid(row=20, column=0, columnspan=2,
                                               pady=30, sticky="ew")

    def _selecionar_status(self, valor):
        self.status_var.set(valor)
        for s, b in self.status_btns.items():
            b.configure(border_width=3 if s == valor else 0,
                        border_color=BRANCO if s == valor else {"Quero Ler":"#8B5A2B","Lendo":VERDE_OLIVA,"Lido":"#2D6A2D"}[s],
                        fg_color={"Quero Ler":"#8B5A2B","Lendo":VERDE_OLIVA,"Lido":"#2D6A2D"}[s])

    def selecionar_capa(self):
        path = filedialog.askopenfilename(
            filetypes=[("Imagens", "*.png *.jpg *.jpeg *.webp"), ("Todos", "*.*")])
        if path:
            self.capa_path = path
            self.lbl_capa.configure(text=os.path.basename(path))

    def buscar(self):
        termo = self.ent_busca.get().strip()
        if not termo:
            return
        resultados = buscar_por_titulo_autor(termo)
        if not resultados:
            messagebox.showinfo("Busca", "Nenhum resultado encontrado.")
            return
        livro = resultados[0]
        self.inputs['titulo'].delete(0, 'end')
        self.inputs['titulo'].insert(0, livro.get('titulo', ''))
        self.inputs['autor'].set(livro.get('autor', ''))
        self.inputs['paginas'].delete(0, 'end')
        self.inputs['paginas'].insert(0, str(livro.get('paginas', '')))
        self.inputs['ano'].delete(0, 'end')
        self.inputs['ano'].insert(0, str(livro.get('ano', '')))
        if livro.get('genero') and livro['genero'] != '-':
            self.inputs['genero'].set(livro['genero'])

    def salvar(self):
        titulo = self.inputs['titulo'].get().strip()
        if not titulo:
            messagebox.showwarning("Atenção", "O título é obrigatório.")
            return

        dados = {
            'titulo':    titulo,
            'autor':     self.inputs['autor'].get().strip(),
            'genero':    self.inputs['genero'].get().strip(),
            'editora':   self.inputs['editora'].get().strip(),
            'paginas':   self.inputs['paginas'].get().strip(),
            'ano':       self.inputs['ano'].get().strip(),
            'formato':   self.inputs['formato'].get(),
            'status':    self.status_var.get(),
            'lido':      self.status_var.get() == 'Lido',
            'avaliacao': self.avaliacao_widget.get() if self.avaliacao_widget else 0,
            'capa_path': self.capa_path,
        }

        ok = adicionar_livro(dados)
        if ok:
            messagebox.showinfo("Sucesso", f'"{titulo}" cadastrado com sucesso!')
            self._limpar()
            self.app.mostrar_tela("biblioteca")
        else:
            messagebox.showerror("Erro", "Não foi possível salvar. Verifique o banco de dados.")

    def _limpar(self):
        self.inputs['titulo'].delete(0, 'end')
        self.inputs['autor'].set('')
        self.inputs['genero'].set('')
        self.inputs['editora'].set('')
        self.inputs['paginas'].delete(0, 'end')
        self.inputs['ano'].delete(0, 'end')
        self.inputs['formato'].set('Físico')
        self._selecionar_status('Quero Ler')
        if self.avaliacao_widget:
            self.avaliacao_widget.set(0)
        self.capa_path = None
        self.lbl_capa.configure(text="Nenhuma imagem selecionada")
        self.ent_busca.delete(0, 'end')
