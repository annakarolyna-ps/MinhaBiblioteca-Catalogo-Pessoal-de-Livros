import customtkinter as ctk

CHEIA = "★"
VAZIA = "☆"
MEIA = "⯪"

class WidgetEstrelas(ctk.CTkFrame):
    def __init__(self, master, valor_inicial=0.0, callback=None, tamanho=14, readonly=False, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)
        self.valor = float(valor_inicial)
        self.callback = callback
        self.tamanho = tamanho
        self.readonly = readonly
        self.btns = []
        self._build()
        self._render(self.valor)

    def _build(self):
        for i in range(5):
            btn = ctk.CTkButton(
                self,
                text=VAZIA,
                width=self.tamanho + 6,
                height=self.tamanho + 6,
                font=ctk.CTkFont(size=self.tamanho),
                fg_color="transparent",
                hover_color=("gray85", "gray25"),
                text_color="#E6A817",
                border_width=0,
                corner_radius=2,
            )
            btn.grid(row=0, column=i, padx=0, pady=0)
            if not self.readonly:
                btn.bind("<Button-1>", lambda e, idx=i: self._click(e, idx))
                btn.bind("<Motion>", lambda e, idx=i: self._hover(e, idx))
                btn.bind("<Leave>", lambda e: self._render(self.valor))
            self.btns.append(btn)

    def _valor_do_evento(self, event, idx):
        w = event.widget.winfo_width()
        return idx + 0.5 if event.x < w / 2 else idx + 1.0

    def _click(self, event, idx):
        self.valor = self._valor_do_evento(event, idx)
        self._render(self.valor)
        if self.callback:
            self.callback(self.valor)

    def _hover(self, event, idx):
        val = self._valor_do_evento(event, idx)
        self._render(val)

    def _render(self, val):
        for i, btn in enumerate(self.btns):
            if val >= i + 1:
                btn.configure(text=CHEIA)
            elif val >= i + 0.5:
                btn.configure(text=MEIA)
            else:
                btn.configure(text=VAZIA)

    def get(self):
        return self.valor

    def set(self, valor):
        self.valor = float(valor)
        self._render(self.valor)
