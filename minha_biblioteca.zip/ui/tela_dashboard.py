import customtkinter as ctk
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from .styles import *
from database.dashboard_data import (stats_gerais, livros_por_genero,
                                      lidos_por_ano, autores_mais_lidos,
                                      distribuicao_avaliacoes, ritmo_leitura_mensal)

# Paleta consistente com a UI
C_VERDE      = "#4E7A4C"
C_VERDE_ESC  = "#2D4A2B"
C_CAFE       = "#6B3F2A"
C_MARROM     = "#2D1E17"
C_BEGE       = "#C49A6C"
C_VERM       = "#A63D2F"
C_FUNDO      = "#FAF9F6"
C_BRANCO     = "#FFFFFF"
C_CINZA      = "#888888"
C_GRADE      = "#E8E4DF"

def _aplicar_estilo():
    plt.rcParams.update({
        'figure.facecolor':  C_FUNDO,
        'axes.facecolor':    C_BRANCO,
        'axes.edgecolor':    C_GRADE,
        'axes.labelcolor':   C_MARROM,
        'axes.spines.top':   False,
        'axes.spines.right': False,
        'text.color':        C_MARROM,
        'xtick.color':       C_CINZA,
        'ytick.color':       C_CINZA,
        'xtick.labelsize':   8,
        'ytick.labelsize':   8,
        'font.family':       'sans-serif',
        'grid.color':        C_GRADE,
        'grid.linewidth':    0.7,
    })

class TelaDashboard(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color=FUNDO_CLARO, corner_radius=0)
        self.app = app
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=30, pady=(30,10))
        ctk.CTkLabel(header, text="Estatísticas e Insights", font=FONTE_TITULO,
                     text_color=TEXTO_PRINCIPAL).pack(side="left")

        self.scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        self.scroll.grid(row=1, column=0, sticky="nsew", padx=20, pady=10)
        self.scroll.grid_columnconfigure(0, weight=1)

    def atualizar(self):
        for w in self.scroll.winfo_children():
            w.destroy()
        stats = stats_gerais()
        self._cards_resumo(stats)
        self._graficos(stats)

    # ── Cards de resumo ───────────────────────────────────────────────────────

    def _cards_resumo(self, stats):
        row = ctk.CTkFrame(self.scroll, fg_color="transparent")
        row.grid(row=0, column=0, sticky="ew", pady=(0,16))
        for i in range(5):
            row.grid_columnconfigure(i, weight=1)

        media_str = f"{stats['media_avaliacao']:.1f} ★" if stats['media_avaliacao'] else "—"
        items = [
            ("📚", "TOTAL",       str(stats['total']),       C_CAFE),
            ("✅", "LIDOS",       str(stats['lidos']),        C_VERDE_ESC),
            ("📖", "LENDO",       str(stats['lendo']),        C_VERDE),
            ("🕒", "QUERO LER",   str(stats['nao_lidos']),   C_CAFE),
            ("⭐", "MÉDIA AVAL.", media_str,                  "#C8930A"),
        ]
        for col, (ic, tit, val, cor) in enumerate(items):
            f = ctk.CTkFrame(row, fg_color=C_BRANCO, corner_radius=CORNER_RADIUS,
                             border_width=1, border_color=C_GRADE)
            f.grid(row=0, column=col, padx=5, sticky="ew")
            f.grid_columnconfigure(0, weight=1)
            ctk.CTkFrame(f, fg_color=cor, height=4,
                         corner_radius=CORNER_RADIUS).grid(row=0, column=0, sticky="ew")
            ctk.CTkLabel(f, text=ic, font=("Segoe UI", 26)).grid(row=1, column=0, pady=(12,4))
            ctk.CTkLabel(f, text=tit, font=("Segoe UI", 9, "bold"),
                         text_color=C_CINZA).grid(row=2, column=0)
            ctk.CTkLabel(f, text=val, font=FONTE_CARD_VALOR,
                         text_color=cor).grid(row=3, column=0, pady=(2,14))

    # ── Gráficos ──────────────────────────────────────────────────────────────

    def _graficos(self, stats):
        _aplicar_estilo()

        fig = plt.figure(figsize=(12, 14), facecolor=C_FUNDO)
        fig.subplots_adjust(hspace=0.55, wspace=0.35,
                            left=0.07, right=0.97, top=0.97, bottom=0.05)

        gs = gridspec.GridSpec(3, 4, figure=fig)

        # ── Linha 1: Gêneros (2/4) + Rosca status (1/4) + Avaliações (1/4) ──
        ax_gen = fig.add_subplot(gs[0, :2])
        ax_ros = fig.add_subplot(gs[0, 2])
        ax_av  = fig.add_subplot(gs[0, 3])

        # Gêneros — barra horizontal
        dados_g = livros_por_genero()
        if dados_g:
            labels = [d['genero'] for d in dados_g[:6]]
            vals   = [d['total']  for d in dados_g[:6]]
            cores  = [C_VERDE, C_VERDE_ESC, C_CAFE, C_BEGE, C_VERM, C_MARROM][:len(labels)]
            bars = ax_gen.barh(labels, vals, color=cores, height=0.55)
            ax_gen.bar_label(bars, padding=4, color=C_MARROM, fontsize=8, fontweight='bold')
            ax_gen.invert_yaxis()
            ax_gen.set_xlabel("Livros", color=C_CINZA, fontsize=8)
            ax_gen.tick_params(axis='y', labelsize=8)
        else:
            ax_gen.text(0.5, 0.5, "Sem dados", ha='center', va='center', color=C_CINZA)
        ax_gen.set_title("Top Gêneros", fontweight='bold', color=C_MARROM, pad=10)

        # Rosca status
        vs = [stats['lidos'], stats['lendo'], stats['nao_lidos']]
        ls = ['Lidos', 'Lendo', 'Quero Ler']
        cs = [C_VERDE_ESC, C_VERDE, C_CAFE]
        filtrado = [(v,l,c) for v,l,c in zip(vs,ls,cs) if v>0]
        if filtrado:
            fvs,fls,fcs = zip(*filtrado)
            wedges,_,_ = ax_ros.pie(fvs, colors=fcs, startangle=90,
                                     wedgeprops={'width':0.55},
                                     autopct='%1.0f%%', pctdistance=0.77,
                                     textprops={'fontsize':8,'color':C_BRANCO})
            ax_ros.legend(wedges, fls, loc='lower center',
                          bbox_to_anchor=(0.5,-0.18), ncol=1,
                          fontsize=7, frameon=False)
        else:
            ax_ros.text(0.5,0.5,"Sem dados",ha='center',va='center',color=C_CINZA)
        ax_ros.set_title("Status", fontweight='bold', color=C_MARROM, pad=10)

        # Avaliações — barras verticais
        dados_av = distribuicao_avaliacoes()
        if dados_av:
            notas = [f"{'★'*d['nota']}" for d in dados_av]
            vals  = [d['total'] for d in dados_av]
            bars  = ax_av.bar(notas, vals, color=C_BEGE, width=0.5, edgecolor=C_CAFE, linewidth=0.8)
            ax_av.bar_label(bars, padding=3, fontsize=8, color=C_MARROM, fontweight='bold')
            ax_av.set_ylim(0, max(vals)+1.5)
            ax_av.tick_params(axis='x', labelsize=7)
        else:
            ax_av.text(0.5,0.5,"Sem dados",ha='center',va='center',color=C_CINZA)
        ax_av.set_title("Avaliações", fontweight='bold', color=C_MARROM, pad=10)

        # ── Linha 2: Ritmo mensal (4/4) ──────────────────────────────────────
        ax_mes = fig.add_subplot(gs[1, :])
        dados_m = ritmo_leitura_mensal()
        if dados_m:
            meses = [d['mes']   for d in dados_m]
            vals  = [d['total'] for d in dados_m]
            bars  = ax_mes.bar(meses, vals, color=C_VERDE, width=0.55,
                               edgecolor=C_VERDE_ESC, linewidth=0.6)
            ax_mes.bar_label(bars, padding=4, fontsize=8,
                             color=C_MARROM, fontweight='bold')
            ax_mes.set_ylim(0, max(vals)+1.5)
            ax_mes.yaxis.grid(True, linestyle='--', alpha=0.5)
            ax_mes.set_axisbelow(True)
            plt.setp(ax_mes.get_xticklabels(), rotation=30, ha='right')
        else:
            ax_mes.text(0.5,0.5,"Sem leituras nos últimos 12 meses",
                        ha='center',va='center',color=C_CINZA)
        ax_mes.set_title("Ritmo de Leitura — Últimos 12 Meses",
                         fontweight='bold', color=C_MARROM, pad=10)

        # ── Linha 3: Evolução anual (2/4) + Autores (2/4) ────────────────────
        ax_ano = fig.add_subplot(gs[2, :2])
        ax_aut = fig.add_subplot(gs[2, 2:])

        dados_a = lidos_por_ano()
        if dados_a:
            anos = [str(d['ano']) for d in dados_a]
            vals = [d['total']    for d in dados_a]
            ax_ano.plot(anos, vals, marker='o', color=C_VERDE,
                        linewidth=2.5, markersize=9, markerfacecolor=C_VERDE_ESC)
            ax_ano.fill_between(anos, vals, color=C_VERDE, alpha=0.1)
            for x,y in zip(anos,vals):
                ax_ano.annotate(str(y),(x,y), textcoords="offset points",
                                xytext=(0,9), ha='center', fontsize=8,
                                fontweight='bold', color=C_MARROM)
            ax_ano.set_ylim(0, max(vals)+2)
            ax_ano.yaxis.grid(True, linestyle='--', alpha=0.5)
            ax_ano.set_axisbelow(True)
        else:
            ax_ano.text(0.5,0.5,"Sem dados de leituras concluídas",
                        ha='center',va='center',color=C_CINZA)
        ax_ano.set_title("Livros Lidos por Ano", fontweight='bold',
                         color=C_MARROM, pad=10)

        dados_au = autores_mais_lidos()
        if dados_au:
            nomes = [d['autor'].split()[0] for d in dados_au]
            vals  = [d['total'] for d in dados_au]
            cores = [C_CAFE, C_MARROM, C_BEGE, C_VERM, C_VERDE, C_VERDE_ESC][:len(nomes)]
            bars  = ax_aut.bar(nomes, vals, color=cores, width=0.55)
            ax_aut.bar_label(bars, padding=4, fontsize=8,
                             color=C_MARROM, fontweight='bold')
            ax_aut.set_ylim(0, max(vals)+1.5)
            ax_aut.yaxis.grid(True, linestyle='--', alpha=0.5)
            ax_aut.set_axisbelow(True)
            plt.setp(ax_aut.get_xticklabels(), rotation=20, ha='right')
        else:
            ax_aut.text(0.5,0.5,"Sem dados",ha='center',va='center',color=C_CINZA)
        ax_aut.set_title("Autores Favoritos", fontweight='bold',
                         color=C_MARROM, pad=10)

        canvas = FigureCanvasTkAgg(fig, master=self.scroll)
        canvas.draw()
        canvas.get_tk_widget().grid(row=1, column=0, sticky="nsew", pady=10)
