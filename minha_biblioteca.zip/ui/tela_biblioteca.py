import customtkinter as ctk
from PIL import Image
import os
from tkinter import filedialog, messagebox
from .styles import *
from .widget_estrelas import WidgetEstrelas
from database.livros import (listar_livros, buscar_livros, deletar_libro,
                              atualizar_capa, obter_livro, editar_livro,
                              listar_autores, listar_generos, listar_editoras)

STATUS_CORES = {"Lido": "#2D6A2D", "Lendo": "#4E7A4C", "Quero Ler": "#8B5A2B"}
FORMATOS = ["Físico", "E-book", "Audiobook"]
STATUS_OPT = ["Quero Ler", "Lendo", "Lido"]

class TelaBiblioteca(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color=FUNDO_CLARO, corner_radius=0)
        self.app = app
        self.filtro_atual = None
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # ── Header ────────────────────────────────────────────────────────
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=30, pady=(30,10))
        header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(header, text="Minha Biblioteca", font=FONTE_TITULO,
                     text_color=TEXTO_PRINCIPAL).grid(row=0, column=0, sticky="w")

        # ── Busca + filtros ───────────────────────────────────────────────
        barra = ctk.CTkFrame(self, fg_color="transparent")
        barra.grid(row=1, column=0, sticky="ew", padx=30, pady=(0,10))
        barra.grid_columnconfigure(0, weight=1)

        busca_f = ctk.CTkFrame(barra, fg_color=BRANCO, corner_radius=8,
                               border_width=1, border_color="#E0E0E0")
        busca_f.grid(row=0, column=0, sticky="ew")
        busca_f.grid_columnconfigure(0, weight=1)

        self.ent_busca = ctk.CTkEntry(busca_f, placeholder_text="🔍  Buscar por título ou autor...",
                                      height=38, border_width=0, fg_color="transparent")
        self.ent_busca.grid(row=0, column=0, sticky="ew", padx=10)
        self.ent_busca.bind("<Return>", lambda e: self.buscar())
        self.ent_busca.bind("<KeyRelease>", self._busca_ao_limpar)
        ctk.CTkButton(busca_f, text="Buscar", width=80, height=28, fg_color=VERDE_OLIVA,
                      hover_color=VERDE_HOVER, command=self.buscar).grid(row=0, column=1, padx=8, pady=5)

        filtros_f = ctk.CTkFrame(barra, fg_color="transparent")
        filtros_f.grid(row=0, column=1, padx=(12,0))
        self.btns_filtro = {}
        for label, val in [("Todos", None), ("Quero Ler", "Quero Ler"),
                           ("Lendo", "Lendo"), ("Lidos", "Lidos")]:
            b = ctk.CTkButton(filtros_f, text=label, width=85, height=38,
                              fg_color=VERDE_OLIVA if val is None else BRANCO,
                              text_color=BRANCO if val is None else TEXTO_PRINCIPAL,
                              border_width=1, border_color="#CCCCCC",
                              hover_color=VERDE_HOVER,
                              command=lambda v=val, l=label: self.filtrar(v, l))
            b.pack(side="left", padx=3)
            self.btns_filtro[label] = b

        # ── Tabela ────────────────────────────────────────────────────────
        self.tabela_container = ctk.CTkFrame(self, fg_color=BRANCO, corner_radius=CORNER_RADIUS,
                                             border_width=1, border_color="#E0E0E0")
        self.tabela_container.grid(row=2, column=0, sticky="nsew", padx=30, pady=(0,30))

        cab = ctk.CTkFrame(self.tabela_container, fg_color=MARROM_ESCUDO, height=45, corner_radius=0)
        cab.pack(fill="x")
        cab.pack_propagate(False)
        self._grid(cab)
        for txt, col in [("#",0),("CAPA",1),("TÍTULO E AUTOR",2),("GÊNERO",3),
                         ("PÁG.",4),("STATUS",5),("AVALIAÇÃO",6),("",7)]:
            ctk.CTkLabel(cab, text=txt, font=FONTE_PEQUENA, text_color=BRANCO).grid(
                row=0, column=col, sticky="nsew")

        self.scroll = ctk.CTkScrollableFrame(self.tabela_container, fg_color="transparent", corner_radius=0)
        self.scroll.pack(fill="both", expand=True)
        self._grid(self.scroll)

        self.atualizar_lista()

    def _grid(self, frame):
        frame.grid_columnconfigure(0, minsize=45,  weight=0, uniform="c")
        frame.grid_columnconfigure(1, minsize=110, weight=0, uniform="c")
        frame.grid_columnconfigure(2, minsize=260, weight=1)
        frame.grid_columnconfigure(3, minsize=130, weight=0, uniform="c")
        frame.grid_columnconfigure(4, minsize=60,  weight=0, uniform="c")
        frame.grid_columnconfigure(5, minsize=90,  weight=0, uniform="c")
        frame.grid_columnconfigure(6, minsize=140, weight=0, uniform="c")
        frame.grid_columnconfigure(7, minsize=40,  weight=0, uniform="c")

    def atualizar_lista(self, livros=None):
        for w in self.scroll.winfo_children():
            w.destroy()
        if livros is None:
            livros = listar_livros(self.filtro_atual)
        if not livros:
            ctk.CTkLabel(self.scroll, text="Nenhum livro encontrado.",
                         font=FONTE_NORMAL, text_color=CINZA_TEXTO).grid(
                         row=0, column=0, columnspan=8, pady=40)
            return
        for i, livro in enumerate(livros):
            bg = BRANCO if i % 2 == 0 else "#F7F5F2"
            row_f = ctk.CTkFrame(self.scroll, fg_color=bg, height=100, corner_radius=0)
            row_f.pack(fill="x")
            row_f.pack_propagate(False)
            self._grid(row_f)

            # 0 — número
            ctk.CTkLabel(row_f, text=str(i+1), text_color=CINZA_TEXTO,
                         font=FONTE_PEQUENA).grid(row=0, column=0)

            # 1 — capa + botão trocar
            capa_f = ctk.CTkFrame(row_f, fg_color="transparent")
            capa_f.grid(row=0, column=1)
            img = self._img(livro.get('capa_path'), (45,65))
            if img:
                ctk.CTkLabel(capa_f, image=img, text="").pack(pady=(8,2))
            else:
                ctk.CTkLabel(capa_f, text="📔", font=("Segoe UI",24)).pack(pady=(8,2))
            ctk.CTkButton(capa_f, text="🖼️", width=28, height=18,
                          fg_color="transparent", text_color=VERDE_OLIVA,
                          hover_color="#E8F0E8",
                          command=lambda id=livro['id']: self.mudar_capa(id)).pack()

            # 2 — título e autor
            info = ctk.CTkFrame(row_f, fg_color="transparent")
            info.grid(row=0, column=2, sticky="ew", padx=10)
            info.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(info, text=livro['titulo'], font=FONTE_CARD_TITULO,
                         text_color=TEXTO_PRINCIPAL, anchor="w",
                         wraplength=240).grid(row=0, column=0, sticky="ew", pady=(22,0))
            ctk.CTkLabel(info, text=livro.get('autor') or "Desconhecido",
                         font=FONTE_PEQUENA, text_color=CINZA_TEXTO,
                         anchor="w").grid(row=1, column=0, sticky="ew")

            # 3 — gênero
            ctk.CTkLabel(row_f, text=livro.get('genero') or "-",
                         text_color=TEXTO_PRINCIPAL, wraplength=120,
                         justify="center", font=FONTE_PEQUENA).grid(row=0, column=3, padx=4)

            # 4 — páginas
            ctk.CTkLabel(row_f, text=str(livro.get('paginas') or "-"),
                         text_color=TEXTO_PRINCIPAL, font=FONTE_PEQUENA).grid(row=0, column=4)

            # 5 — badge status
            st = livro.get('status') or 'Quero Ler'
            badge = ctk.CTkFrame(row_f, fg_color=STATUS_CORES.get(st, CINZA_TEXTO),
                                 corner_radius=6)
            badge.grid(row=0, column=5, padx=4)
            ctk.CTkLabel(badge, text=st, font=("Segoe UI",9,"bold"),
                         text_color=BRANCO).pack(padx=8, pady=4)

            # 6 — avaliação
            aval_f = ctk.CTkFrame(row_f, fg_color="transparent")
            aval_f.grid(row=0, column=6)
            WidgetEstrelas(aval_f, valor_inicial=float(livro.get('avaliacao') or 0),
                           readonly=True, tamanho=12).pack(pady=38)

            # 7 — ações (editar + excluir)
            acoes = ctk.CTkFrame(row_f, fg_color="transparent")
            acoes.grid(row=0, column=7)
            ctk.CTkButton(acoes, text="✏️", width=28, height=28,
                          fg_color="transparent", text_color=VERDE_OLIVA,
                          hover_color="#E8F0E8",
                          command=lambda l=livro: self.abrir_edicao(l)).pack(pady=(0,2))
            ctk.CTkButton(acoes, text="🗑️", width=28, height=28,
                          fg_color="transparent", text_color="red",
                          hover_color="#FFF0F0",
                          command=lambda id=livro['id']: self.excluir(id)).pack()

            ctk.CTkFrame(self.scroll, fg_color="#EEEEEE", height=1).pack(fill="x")

    def filtrar(self, status, label):
        self.filtro_atual = status
        for l, b in self.btns_filtro.items():
            ativo = l == label
            b.configure(fg_color=VERDE_OLIVA if ativo else BRANCO,
                        text_color=BRANCO if ativo else TEXTO_PRINCIPAL)
        self.atualizar_lista()

    def buscar(self):
        termo = self.ent_busca.get().strip()
        if termo:
            self.atualizar_lista(buscar_livros(termo))
        else:
            self.atualizar_lista()

    def _busca_ao_limpar(self, event):
        if self.ent_busca.get().strip() == "":
            self.atualizar_lista()

    def _img(self, path, size):
        try:
            if path and os.path.exists(path):
                img = Image.open(path)
                return ctk.CTkImage(light_image=img, dark_image=img, size=size)
        except:
            return None

    def excluir(self, id):
        if messagebox.askyesno("Excluir", "Tem certeza que deseja excluir este livro?"):
            if deletar_libro(id):
                self.atualizar_lista()

    def mudar_capa(self, id):
        path = filedialog.askopenfilename(
            filetypes=[("Imagens", "*.png *.jpg *.jpeg *.webp"), ("Todos", "*.*")])
        if path and atualizar_capa(id, path):
            self.atualizar_lista()

    def abrir_edicao(self, livro):
        JanelaEdicao(self, livro, self.atualizar_lista)


class JanelaEdicao(ctk.CTkToplevel):
    def __init__(self, master, livro, callback):
        super().__init__(master)
        self.livro = livro
        self.callback = callback
        self.title(f"Editar — {livro['titulo']}")
        self.geometry("520x640")
        self.resizable(False, False)
        self.grab_set()
        self.configure(fg_color=FUNDO_CLARO)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.grid(row=0, column=0, sticky="nsew", padx=20, pady=10)
        scroll.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(scroll, text=f"✏️  Editar: {livro['titulo']}", font=FONTE_SUBTITULO,
                     text_color=TEXTO_PRINCIPAL).grid(row=0, column=0, columnspan=2,
                     sticky="w", padx=4, pady=(8,16))

        def lbl(row, txt):
            ctk.CTkLabel(scroll, text=txt, font=FONTE_PEQUENA,
                         text_color=TEXTO_PRINCIPAL).grid(row=row, column=0, sticky="w", pady=5)

        def ent(row, val=""):
            e = ctk.CTkEntry(scroll, height=34)
            e.grid(row=row, column=1, sticky="ew", pady=5, padx=(12,0))
            if val: e.insert(0, str(val))
            return e

        def cmb(row, values, val=""):
            c = ctk.CTkComboBox(scroll, values=values, height=34)
            if val: c.set(str(val))
            c.grid(row=row, column=1, sticky="ew", pady=5, padx=(12,0))
            return c

        lbl(1, "Título *");  self.e_titulo  = ent(1, livro.get('titulo',''))
        lbl(2, "Autor");     self.e_autor   = cmb(2, [a['nome'] for a in listar_autores()], livro.get('autor',''))
        lbl(3, "Gênero");    self.e_genero  = cmb(3, [g['nome'] for g in listar_generos()], livro.get('genero',''))
        lbl(4, "Editora");   self.e_editora = cmb(4, [e['nome'] for e in listar_editoras()], livro.get('editora',''))
        lbl(5, "Páginas");   self.e_paginas = ent(5, livro.get('paginas',''))
        lbl(6, "Ano");       self.e_ano     = ent(6, livro.get('ano_publicacao',''))
        lbl(7, "Formato");   self.e_formato = cmb(7, FORMATOS, livro.get('formato','Físico'))

        # Status
        lbl(8, "Status")
        self.status_var = ctk.StringVar(value=livro.get('status','Quero Ler'))
        st_f = ctk.CTkFrame(scroll, fg_color="transparent")
        st_f.grid(row=8, column=1, sticky="ew", pady=5, padx=(12,0))
        self.st_btns = {}
        cores = {"Quero Ler":"#8B5A2B","Lendo":VERDE_OLIVA,"Lido":"#2D6A2D"}
        for s in STATUS_OPT:
            b = ctk.CTkButton(st_f, text=s, width=90, height=30, fg_color=cores[s],
                              hover_color=VERDE_HOVER, font=FONTE_PEQUENA,
                              command=lambda v=s: self._status(v))
            b.pack(side="left", padx=(0,5))
            self.st_btns[s] = b
        self._status(livro.get('status','Quero Ler'))

        # Avaliação
        lbl(9, "Avaliação")
        av_f = ctk.CTkFrame(scroll, fg_color="transparent")
        av_f.grid(row=9, column=1, sticky="w", pady=5, padx=(12,0))
        self.aval = WidgetEstrelas(av_f, valor_inicial=float(livro.get('avaliacao') or 0), tamanho=18)
        self.aval.pack()

        ctk.CTkButton(scroll, text="💾  Salvar Alterações", height=44,
                      fg_color=VERDE_OLIVA, hover_color=VERDE_HOVER,
                      font=FONTE_CARD_TITULO,
                      command=self.salvar).grid(row=20, column=0, columnspan=2,
                                               sticky="ew", pady=24)

    def _status(self, val):
        self.status_var.set(val)
        cores = {"Quero Ler":"#8B5A2B","Lendo":VERDE_OLIVA,"Lido":"#2D6A2D"}
        for s, b in self.st_btns.items():
            b.configure(border_width=3 if s==val else 0,
                        border_color=BRANCO if s==val else {"Quero Ler":"#8B5A2B","Lendo":VERDE_OLIVA,"Lido":"#2D6A2D"}[s],
                        fg_color=cores[s])

    def salvar(self):
        titulo = self.e_titulo.get().strip()
        if not titulo:
            messagebox.showwarning("Atenção", "O título é obrigatório.")
            return
        dados = {
            'titulo':   titulo,
            'autor':    self.e_autor.get().strip(),
            'genero':   self.e_genero.get().strip(),
            'editora':  self.e_editora.get().strip(),
            'paginas':  self.e_paginas.get().strip(),
            'ano':      self.e_ano.get().strip(),
            'formato':  self.e_formato.get(),
            'status':   self.status_var.get(),
            'lido':     self.status_var.get() == 'Lido',
            'avaliacao':self.aval.get(),
        }
        if editar_livro(self.livro['id'], dados):
            self.callback()
            self.destroy()
        else:
            messagebox.showerror("Erro", "Não foi possível salvar.")
