# ── Paleta principal ──────────────────────────────────────────────────────────
MARROM_ESCUDO   = "#2D1E17"   # sidebar e cabeçalhos
MARROM_CAFE     = "#6B3F2A"   # acentos quentes (ícones livro, relógio)
VERDE_OLIVA     = "#4E7A4C"   # botões principais
VERDE_HOVER     = "#3D613B"
VERDE_ESCURO    = "#2D4A2B"   # ícone check
VERMELHO_SUAVE  = "#A63D2F"   # ícone páginas
FUNDO_CLARO     = "#FAF9F6"   # creme
BRANCO          = "#FFFFFF"
CINZA_TEXTO     = "#888888"
TEXTO_PRINCIPAL = "#2D1E17"

# Aliases para compatibilidade
VERDE_MEDIO = VERDE_OLIVA

# ── Fontes ────────────────────────────────────────────────────────────────────
FONTE_TITULO      = ("Georgia",   24, "bold")
FONTE_SUBTITULO   = ("Georgia",   18, "bold")
FONTE_CARD_TITULO = ("Segoe UI",  12, "bold")
FONTE_CARD_VALOR  = ("Segoe UI",  26, "bold")
FONTE_NORMAL      = ("Segoe UI",  12)
FONTE_PEQUENA     = ("Segoe UI",  10)

# ── UI ────────────────────────────────────────────────────────────────────────
CORNER_RADIUS  = 12
SIDEBAR_WIDTH  = 240
