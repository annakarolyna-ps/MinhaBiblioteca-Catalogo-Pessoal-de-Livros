import customtkinter as ctk
from datetime import datetime
from PIL import Image
import os
from .styles import *
from database.livros import total_livros, lidos_no_ano, livro_lendo_now, obter_meta, total_paginas_lidas

class TelaInicio(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color=FUNDO_CLARO, corner_radius=0)
        self.app = app
        self.grid_columnconfigure(0, weight=1)

        # Header
        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, sticky="ew", padx=30, pady=(30, 20))
        ctk.CTkLabel(self.header, text="Panorama de Leitura", font=FONTE_TITULO,
                     text_color=TEXTO_PRINCIPAL).pack(anchor="w")

        # Cards
        self.cards_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.cards_frame.grid(row=1, column=0, sticky="ew", padx=30, pady=10)
        for i in range(4):
            self.cards_frame.grid_columnconfigure(i, weight=1)
        self.setup_cards()

        # Lendo Agora
        self.mid_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.mid_frame.grid(row=2, column=0, sticky="nsew", padx=30, pady=20)
        self.mid_frame.grid_columnconfigure(0, weight=1)
        self.setup_lendo_agora()

        # Meta
        self.setup_meta_leitura()

    def setup_cards(self):
        # (titulo, icone, cor_icone, cor_valor)
        dados = [
            ("TOTAL DE LIVROS", "📚", MARROM_CAFE,   MARROM_CAFE),
            ("LIVROS LIDOS",    "✅", VERDE_ESCURO,  VERDE_ESCURO),
            ("LENDO AGORA",     "🕒", MARROM_CAFE,   MARROM_CAFE),
            ("TOTAL PÁGINAS",   "🎯", VERMELHO_SUAVE, VERMELHO_SUAVE),
        ]
        self.card_widgets = []
        for i, (titulo, icone, cor_ic, cor_val) in enumerate(dados):
            card = ctk.CTkFrame(self.cards_frame, fg_color=BRANCO,
                                corner_radius=CORNER_RADIUS,
                                border_width=1, border_color="#E0E0E0")
            card.grid(row=0, column=i, padx=5, sticky="ew")
            # faixa colorida no topo
            ctk.CTkFrame(card, fg_color=cor_ic, height=4,
                         corner_radius=0).pack(fill="x")
            ctk.CTkLabel(card, text=icone, font=("Segoe UI", 24),
                         text_color=cor_ic).pack(pady=(14, 5))
            ctk.CTkLabel(card, text=titulo, font=("Segoe UI", 10, "bold"),
                         text_color="#555555").pack()
            lbl = ctk.CTkLabel(card, text="—", font=FONTE_CARD_VALOR,
                               text_color=cor_val)
            lbl.pack(pady=(0, 15))
            self.card_widgets.append(lbl)

    def setup_lendo_agora(self):
        # igual ao original — capa à esquerda com destaque
        self.lendo_frame = ctk.CTkFrame(self.mid_frame, fg_color=BRANCO,
                                         corner_radius=CORNER_RADIUS,
                                         border_width=1, border_color="#E0E0E0")
        self.lendo_frame.pack(fill="x", pady=10)

        ctk.CTkLabel(self.lendo_frame, text="📖  Lendo agora",
                     font=FONTE_CARD_TITULO, text_color=VERDE_OLIVA).pack(
                     anchor="w", padx=20, pady=15)

        self.content_lendo = ctk.CTkFrame(self.lendo_frame, fg_color="transparent")
        self.content_lendo.pack(fill="x", padx=20, pady=(0, 20))

        self.lbl_capa_lendo = ctk.CTkLabel(self.content_lendo, text="📔",
                                            font=("Segoe UI", 48))
        self.lbl_capa_lendo.pack(side="left", padx=(0, 20))

        self.info_lendo = ctk.CTkFrame(self.content_lendo, fg_color="transparent")
        self.info_lendo.pack(side="left", fill="both", expand=True)

        self.lbl_lendo_titulo = ctk.CTkLabel(self.info_lendo,
                                              text="Nenhum livro em leitura",
                                              font=FONTE_SUBTITULO,
                                              text_color=TEXTO_PRINCIPAL, anchor="w")
        self.lbl_lendo_titulo.pack(fill="x")
        self.lbl_lendo_autor = ctk.CTkLabel(self.info_lendo, text="-",
                                             font=FONTE_NORMAL,
                                             text_color=CINZA_TEXTO, anchor="w")
        self.lbl_lendo_autor.pack(fill="x")

    def setup_meta_leitura(self):
        # cor original verde oliva
        self.meta_frame = ctk.CTkFrame(self, fg_color=VERDE_OLIVA,
                                        corner_radius=CORNER_RADIUS)
        self.meta_frame.grid(row=3, column=0, sticky="ew", padx=30, pady=20)
        self.meta_frame.grid_columnconfigure(0, weight=1)

        info = ctk.CTkFrame(self.meta_frame, fg_color="transparent")
        info.grid(row=0, column=0, sticky="w", padx=20, pady=20)
        ctk.CTkLabel(info, text=f"Meta de Leitura {datetime.now().year}",
                     font=FONTE_SUBTITULO, text_color=BRANCO).pack(anchor="w")
        self.lbl_meta_desc = ctk.CTkLabel(info, text="0%",
                                           font=FONTE_NORMAL, text_color=BRANCO)
        self.lbl_meta_desc.pack(anchor="w")

        prog = ctk.CTkFrame(self.meta_frame, fg_color="#3D613B", corner_radius=10)
        prog.grid(row=0, column=1, padx=20, pady=20)
        self.lbl_meta_prog = ctk.CTkLabel(prog, text="0 / 0",
                                           font=FONTE_CARD_VALOR, text_color=BRANCO)
        self.lbl_meta_prog.pack(padx=20, pady=5)

    def atualizar(self):
        ano   = datetime.now().year
        lendo = livro_lendo_now()

        self.card_widgets[0].configure(text=str(total_livros()))
        self.card_widgets[1].configure(text=str(lidos_no_ano(ano)))
        self.card_widgets[2].configure(text="1" if lendo else "0")
        self.card_widgets[3].configure(text=str(total_paginas_lidas()))

        if lendo:
            self.lbl_lendo_titulo.configure(text=lendo['titulo'])
            self.lbl_lendo_autor.configure(text=lendo.get('autor', 'Desconhecido'))
            path = lendo.get('capa_path')
            if path and os.path.exists(path):
                img = ctk.CTkImage(light_image=Image.open(path), size=(60, 90))
                self.lbl_capa_lendo.configure(image=img, text="")
        else:
            self.lbl_lendo_titulo.configure(text="Nenhum livro em leitura")
            self.lbl_lendo_autor.configure(text="-")

        meta  = obter_meta(ano)
        lidos = lidos_no_ano(ano)
        if meta > 0:
            self.lbl_meta_desc.configure(
                text=f"Você completou {int((lidos/meta)*100)}% do objetivo de {meta} livros.")
            self.lbl_meta_prog.configure(text=f"{lidos} / {meta}")
